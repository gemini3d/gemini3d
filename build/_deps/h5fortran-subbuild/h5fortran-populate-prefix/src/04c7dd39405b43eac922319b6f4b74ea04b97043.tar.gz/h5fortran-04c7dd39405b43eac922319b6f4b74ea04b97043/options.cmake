message(STATUS "${PROJECT_NAME} ${PROJECT_VERSION} CMake ${CMAKE_VERSION} Toolchain ${CMAKE_TOOLCHAIN_FILE}")

include(GNUInstallDirs)

option(BUILD_SHARED_LIBS "Build shared libraries" OFF)

option(h5fortran_hdf5_zlib "use Zlib when building HDF5" ON)
option(h5fortran_hdf5_nobuild "only find HDF5, do not build HDF5" OFF)

option(h5fortran_warning_as_error "treat warnings as errors" OFF)

option(h5fortran_coverage "Code coverage tests")
option(h5fortran_tidy "Run clang-tidy on the code")

option(h5fortran_matlab "check HDF5 file writes with Matlab")
option(h5fortran_python "check HDF5 file writes with Python")

option(h5fortran_IGNORE_CONDA_LIBRARIES "If ON, CMake will not search for the
hdf5 libraries in a Conda environment." ON)

option(h5fortran_BUILD_TESTING "build tests" ${h5fortran_IS_TOP_LEVEL})

option(h5fortran_find_hdf5_factory "Use FindHDF5.cmake to find HDF5 instead of our custom FindHDF5")

set(FETCHCONTENT_QUIET OFF)
set(FETCHCONTENT_UPDATES_DISCONNECTED ON)

option(h5fortran_ENABLE_RPATH "Enable RPATH in installed MUMPS libraries" OFF)


# Necessary for shared library with Visual Studio / Windows oneAPI
set(CMAKE_WINDOWS_EXPORT_ALL_SYMBOLS true)

if(h5fortran_IS_TOP_LEVEL AND CMAKE_INSTALL_PREFIX_INITIALIZED_TO_DEFAULT)
  set_property(CACHE CMAKE_INSTALL_PREFIX PROPERTY VALUE "${PROJECT_BINARY_DIR}/local")
endif()
